from django.shortcuts import render
from django.http import HttpResponse
from .models import  ScrumyGoals
from . import views



kwargs = {
    'goal_name': 'Learn Django'
}

def index(request) :
    goal_name=ScrumyGoals.objects.filter(**kwargs)
    # return HttpResponse(ScrumyGoals.objects.filter(goal_name ="Learn Django"))
    return HttpResponse(goal_name)
    # context = {
    #     'kwargs': ScrumyGoals.objects.filter(**kwargs)
    # }
    # return render(request, 'samuelamujoscrumy/index.html', context)
   
    # return HttpResponse('kwargs': ScrumyGoals.objects.filter(**kwargs))




def move_goal(request,goal_id):
    try:
        goal = ScrumyGoals.objects.get(goal_id = goal_id)
        return HttpResponse(goal.goal_name)
    except ScrumyGoals.DoesNotExist:
        return HttpResponse('Whatsup....!!! Sorry what you are looking for doesn\'t exist')
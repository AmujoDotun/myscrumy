from django.apps import AppConfig


class SamuelamujoscrumyConfig(AppConfig):
    name = 'samuelamujoscrumy'


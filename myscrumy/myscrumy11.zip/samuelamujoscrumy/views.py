from django.shortcuts import render
from django.http import HttpResponse
from .models import  ScrumyGoals




kwargs = {
    'goal_name': 'Learn Django'
}

def index(request) :
    goal_name=ScrumyGoals.objects.filter(**kwargs)
    # return HttpResponse(ScrumyGoals.objects.filter(goal_name ="Learn Django"))
    return HttpResponse(goal_name)
    # context = {
    #     'kwargs': ScrumyGoals.objects.filter(**kwargs)
    # }
    # return render(request, 'samuelamujoscrumy/index.html', context)
   
    # return HttpResponse('kwargs': ScrumyGoals.objects.filter(**kwargs))